import React, { Component, Fragment } from 'react';
import { Link, Redirect } from 'react-router-dom';
import axios from 'axios';
import {backendUrlBooking} from '../BackendURL';
import {Dialog} from 'primereact/dialog';
import {Button} from 'primereact/button';
import {Growl} from 'primereact/growl';


class ViewBooking extends Component {
    constructor(){
        super();
        this.state = {
            packageDetails : [],
            popupContent : {},
            isPlannedTripPresent : false
        }    
    }

    componentWillMount(){
        axios.get(backendUrlBooking+'/getBooking/'+ sessionStorage.getItem('userId')).then(async(response)=>{
            if (response.data.bookings.length > 0) {
                await this.setState({packageDetails:response.data.bookings,isPlannedTripPresent : true});
            } else {
                await this.setState({isPlannedTripPresent:false});
            }
        });
    }

    async openDialog (pkg) {
        await this.setState({visible: true,popupContent:{startDate:pkg.checkInDate,
            endDate:pkg.checkOutDate,refundAmount:pkg.totalCharges,name:pkg.destinationName,
            destId : pkg.destId,bookingId:pkg.bookingId}});
    }

    spliDestination(name) {
        if (name) {
            let sname =  name.split(':');
            return sname[1];
        }
        return;
    }

    close = () => {
        this.setState({visible:false});
    }

    confirmCancellation = async() => {
        try {
            let response = await axios.delete(backendUrlBooking+'/cancelBooking/'+this.state.popupContent.bookingId);
            this.close();
            this.showInfo();
            setTimeout(() =>{
                window.location.reload(false)
            },700);
        } catch (err) {
        }
    }

    showInfo() {
        this.growl.show({severity: 'info', summary: 'Info Message', 
        detail: 'Successfully deleted with the booking id ' +this.state.popupContent.bookingId });
    }

    render(){
        const footer = (
            <div>
                <Button label="Back"  onClick={this.close} />
                <Button label="Confirm Cancellation"  onClick={this.confirmCancellation} />
            </div>
        );
        return(
            <Fragment>
                <div className="container" style={{padding:85}}>
                <Growl ref={(el) => this.growl = el} position="center"></Growl>
                { this.state.isPlannedTripPresent ?  this.state.packageDetails.map( (pkgs) =>
                (
                    <div className="col-md-8 offset-md-2">
                        <div className="card">
                            <div className="card-header">
                                    <h6>Booking ID : {pkgs.bookingId}</h6>
                            </div>
                            <div className="card-body">
                                <h4>{
                                this.spliDestination(pkgs.destinationName)
                                }</h4>
                                <div className="row">
                                    <div className="col-md-5" style={{textAlign:"left"}}>
                                        <p>Trip starts on : {pkgs.checkInDate} </p>
                                        <p>Trip ends on : {pkgs.checkOutDate}</p>
                                        <p>Travellers : {pkgs.noOfPersons} </p>
                                    </div>
                                    <div className=" offset-md-1 col-md-3" style={{textAlign:"left"}}> 
                                        <p>Fare Details</p>
                                        <p>${pkgs.totalCharges}</p>
                                        
                                        <a icon="pi pi-info-circle" href="javascript::void(0)" onClick={(e) => this.openDialog(pkgs)} >Claim Refund</a>

                                    </div>
                                </div>
                            </div>
                            <div className="card-footer">
                                
                            </div>
                        </div>
                    </div>
                    )) : (<div>
                            <h4>Sorry You have not planned any trips with us Yet!</h4>
                            <Link to="/" className="btn btn-success btn-lg" style={{marginTop:20}} >CLICK HERE TO START BOOKING</Link>
                        </div>) }
                    <Dialog header="Confirm Calcellation" visible={this.state.visible} footer={footer} style={{width: '50vw'}} modal={true} onHide={ this.close }>
                        <p className="text text-danger"> Are you sure you want to cancle your trip to { this.spliDestination(this.state.popupContent.name)}? </p>
                        <p>Trip Start Date :  {this.state.popupContent.startDate}</p>
                        <p>Trip End Date :  {this.state.popupContent.endDate}</p>
                        <p>Refunded Amount : ${this.state.popupContent.refundAmount} </p>
                    </Dialog>
                </div>
            </Fragment>
        );
    }
}

export default ViewBooking;