import React, { Component } from "react";
import axios from "axios";
import { Redirect,Link } from 'react-router-dom';
import {backendUrlPackage, backendUrlBooking} from '../BackendURL';
import register from './register';
import {Panel} from 'primereact/panel';
import { InputSwitch } from 'primereact/inputswitch';

class Book extends Component {
    constructor() {
        super();
        this.state = {
            panelCollapsed1 : true,
            panelCollapsed2 : true,
            panelCollapsed3 : true,
            bookingPkgs : [],
            bookingForm: {
                noOfPersons: sessionStorage.getItem('noOfPersons'),
                date: sessionStorage.getItem('checkInDate'),
                flights: sessionStorage.getItem('flight')
            },
            bookingFormErrorMessage: {
                noOfPersons: "",
                date: ""
            },
            bookingFormValid: {
                noOfPersons: false,
                date: false,
                buttonActive: false
            },
            checkOutDate :  '',
            totalCharges :  '',
            isBookingConfirm : false
        }
    }

    async componentWillMount () {
        let destinationId = sessionStorage.getItem('dealId');
        let flight;
         if (sessionStorage.getItem('flight')) {
             if (sessionStorage.getItem('flight') === 'false') {
                   flight = false;
             } else {
                    flight = true;
             }
         }
        await this.setState({bookingForm:{
            noOfPersons: sessionStorage.getItem('noOfPersons'),
            date: sessionStorage.getItem('checkInDate'),
            flights: flight
        }});
        try {
            let response;
            if ( destinationId[0] === 'H') {
                response = await axios.get(backendUrlPackage+'/hotDeals/'+destinationId);
            } else {
                response = await axios.get(backendUrlPackage+'/getDestination/'+destinationId);
            }
            await this.setState({bookingPkgs:response.data.packages});
            await this.calculateCharges();
        } catch (err) {

        }
    }

    displayPackageInclusions = () => {
        let bkgDetails = this.state.bookingPkgs[0];    
        const packageInclusions = bkgDetails ?  bkgDetails.details.itinerary.packageInclusions : null;
        if(bkgDetails) {
            return packageInclusions.map((pack,index)=> (<li key={index}>{pack}</li>) )
        }
        else {
            return null;
        }
    }

    displayPackageHighlights = () => {
        let packageHighLightsArray = [];
        let firstElement = (
            <div key={0}>
                <h3>Day Wise itinerary</h3>
                <h5>Day 1</h5>
                {this.state.bookingPkgs[0] ? <div>{this.state.bookingPkgs[0].details.itinerary.dayWiseDetails.firstDay}</div> : null}
            </div>
        );
        packageHighLightsArray.push(firstElement);
        if (this.state.bookingPkgs[0]) {
            this.state.bookingPkgs[0].details.itinerary.dayWiseDetails.restDaysSightSeeing.map((packageHighlight,index)=>{
                    let element=(
                        <div key={index+1}>
                        <h5>Day {this.state.bookingPkgs[0].details.itinerary.dayWiseDetails.restDaysSightSeeing.indexOf(packageHighlight) + 2}</h5>
                        <div>{packageHighlight}</div>
                    </div>
                    );
                    packageHighLightsArray.push(element)
                });
            let lastElement = (
                <div key={666}>
                    <h5>Day {this.state.bookingPkgs[0].details.itinerary.dayWiseDetails.restDaysSightSeeing.length + 2}</h5>
                    {this.state.bookingPkgs[0].details.itinerary.dayWiseDetails.lastDay}
                    <div className="text-danger">
                        **This itinerary is just a suggestion, itinerary can be modified as per requirement. <a
                            href="#contact-us">Contact us</a> for more details.
                        </div>
                </div>
            );
            packageHighLightsArray.push(lastElement);
            return packageHighLightsArray;
        } else {
            return null;
        }
    }

    handleChange = (event) => {
        const target = event.target;
        const name = target.name;
        if(target.checked) {
            var value = target.checked;
        } else {
            value = target.value;
        }
        const { bookingForm } = this.state;
        this.setState({
            bookingForm: { ...bookingForm, [name]: value }
        });
        this.validateField(name, value);
        this.calculateCharges();
    }

    calculateCharges = async() => {
        this.setState({ totalCharges: 0 });
        let oneDay = 24 * 60 * 60 * 1000;
        let checkInDate = new Date(this.state.bookingForm.date); 
        let checkOutDateinMs = Math.round(Math.abs((checkInDate.getTime() + (this.state.bookingPkgs[0].noOfNights) * oneDay)));
        let finalCheckOutDate=new Date(checkOutDateinMs);
        await this.setState({ checkOutDate: finalCheckOutDate.toDateString() });
        if (this.state.bookingForm.flights) {
            let totalCost = (-(-this.state.bookingForm.noOfPersons)) * this.state.bookingPkgs[0].chargesPerPerson + this.state.bookingPkgs[0].flightCharges;
            await this.setState({ totalCharges: totalCost });
        } else {
            let totalCost = (-(-this.state.bookingForm.noOfPersons)) * this.state.bookingPkgs[0].chargesPerPerson;
            await this.setState({ totalCharges: totalCost });
        }   
    }

    validateField = (fieldname, value) => {
        let fieldValidationErrors = this.state.bookingFormErrorMessage;
        let formValid = this.state.bookingFormValid;
        switch (fieldname) {
            case "noOfPersons":
                if (value === "") {
                    fieldValidationErrors.noOfPersons = "This field can't be empty!";
                    formValid.noOfPersons = false;
                } else if (value < 1 || value > 5) {
                    fieldValidationErrors.noOfPersons = "No. of persons can't be less than 1!";
                    formValid.noOfPersons = false;
                } else if (value > 5) {
                    fieldValidationErrors.noOfPersons = "No. of persons can't be more than 5.";
                    formValid.noOfPersons = false;
                } else {
                    fieldValidationErrors.noOfPersons = "";
                    formValid.noOfPersons = true;
                }
                break;
            case "date":
                if (value === "") {
                    fieldValidationErrors.date = "This field can't be empty!";
                    formValid.date = false;
                } else {
                    let checkInDate = new Date(value);
                    let today = new Date();
                    if (today.getTime() > checkInDate.getTime()) {
                        fieldValidationErrors.date = "Check-in date cannot be a past date!";
                        formValid.date = false;
                    } else {
                        fieldValidationErrors.date = "";
                        formValid.date = true;
                    }
                }
                break;
            default:
                break;
        }
        formValid.buttonActive = formValid.noOfPersons && formValid.date;
        this.setState({
            loginformErrorMessage: fieldValidationErrors,
            loginformValid: formValid,
            successMessage: ""
        });
    }

    bookTrip = (event) => {
        event.preventDefault();
        console.log( this.state.bookingPkgs[0]);
        let date = new Date(this.state.checkOutDate);
        let month = date .getMonth() < 10 ? '0'+ (date.getMonth()+1) : (date.getMonth()+1);
        let day = date .getDate() < 10 ? '0' + date.getDate() : date.getDate();
        let year = date .getFullYear();
        let checkoutDate = year + "-" + month + "-" + day;
        let bookObj = {
            destId : sessionStorage.getItem('dealId'),
            userId : sessionStorage.getItem('userId'),
            destinationName : this.state.bookingPkgs[0].name,
            checkInDate : sessionStorage.getItem('checkInDate'),
            checkOutDate : checkoutDate,
            noOfPersons : this.state.bookingForm.noOfPersons,
            totalCharges : this.state.totalCharges
        }
        axios.post(backendUrlBooking+'/create',bookObj).then(async(res)=>{
            await this.setState({isBookingConfirm:true});
        }).catch((err)=>{

        })
    }

    formatDate (date) {
        return new Date(date).toDateString();
    }

    spliDestination(name) {
        if (name) {
            let sname =  name.split(':');
            return sname[1];
        }
        return;
    }

    render() {
        return ( 
             <div className="container">
                 {  !this.state.isBookingConfirm ? this.state.bookingPkgs.map((pkg) =>  (
                    <div className='row'>
                        <div className = 'col-md-6'> 
                            <Panel header="Overview" style={{marginTop:'2em'}} toggleable={true} collapsed={this.state.panelCollapsed1} onToggle={(e) => this.setState({panelCollapsed1: e.value})}>
                                {pkg.details ? pkg.details.about : ''} 
                                </Panel>
                                <Panel header="Package Inclusions" style={{marginTop:'2em'}} toggleable={true} collapsed={this.state.panelCollapsed2} onToggle={(e) => this.setState({panelCollapsed2: e.value})}>
                                    { this.displayPackageInclusions() }
                                </Panel>
                                <Panel header="Itinerary" style={{marginTop:'2em',paddingBottom:50}} toggleable={true} collapsed={this.state.panelCollapsed3} onToggle={(e) => this.setState({panelCollapsed3: e.value})}>
                                
                                {this.displayPackageHighlights()}
                            </Panel>
                        </div>       
                        <div className = 'col-md-6' style= {{paddingTop:10,paddingBottom:10}}>
                             <div className="card">
                             <div className="card-header"> 
                                    <form onSubmit={this.handleSubmit}>
                                        <div className="form-group">
                                            <label htmlFor="noOfPersons">Number of Travelers:</label>
                                            <input
                                                type="number"
                                                id="noOfPersons"
                                                className="form-control"
                                                name="noOfPersons"
                                                value={this.state.bookingForm.noOfPersons}
                                                onChange={this.handleChange}
                                            />
                                            {this.state.bookingFormErrorMessage.noOfPersons ?
                                                <span className="text-danger">{this.state.bookingFormErrorMessage.noOfPersons}</span>
                                                : null}
                                        </div>
                                        <div className="form-group">
                                            <label htmlFor="date">Trip start Date:</label>
                                            <input
                                                type="date"
                                                id="date"
                                                className="form-control"
                                                name="date"
                                                value={this.state.bookingForm.date}
                                                onChange={this.handleChange}
                                            />
                                            {this.state.bookingFormErrorMessage.date ?
                                                <span className="text-danger">{this.state.bookingFormErrorMessage.date}</span>
                                                : null}
                                        </div>
                                        <div className="form-group">
                                            <label>Include Flights:</label>&nbsp;
                                            <InputSwitch name="flights" id="flights"
                                                checked={this.state.bookingForm.flights}
                                                onChange={this.handleChange} />
                                        </div>
                                    </form>
                                            <p>Your trip ends on : { this.state.checkOutDate }</p>
                                            <h4>You Pay : ${this.state.totalCharges}</h4>
                                    <div className="text-center">
                                        <button  className="btn btn-success" onClick={ this.bookTrip }>Confirm Booking</button>
                                        &nbsp; &nbsp; &nbsp;
                                        <button type="button" className="btn btn-link" onClick={(e) => this.setState({showItinerary:false})}>Back</button>
                                    </div>
                                </div>
                               </div>
                        </div>
                    </div>
                )) : (<div style = {{padding : 50 }}>
                    
                    <h4>Booking Confirmed!!</h4>
                    <h4 className="text text-success" style={{padding:20}}>Congratulations! Trip planned to { this.state.bookingPkgs[0] ? this.spliDestination(this.state.bookingPkgs[0].name) : '' }</h4>
                    <h6>Trip starts on : { this.formatDate(this.state.bookingForm.date) }</h6>
                    <h6>Trip ends on : { this.state.checkOutDate }</h6>
                    <div style={{paddingTop:40}}>
                        <Link to='/viewBookings'>Click here to view your Bookings</Link>
                    </div>
                </div>) }
            </div>          
        ) 
    }
}

export default Book;

