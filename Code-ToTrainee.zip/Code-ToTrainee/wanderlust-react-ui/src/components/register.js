import React, { Component } from "react";
import axios from "axios";
//import { Redirect } from 'react-router-dom';
import {backendUrlUser} from '../BackendURL';
import { Link } from "react-router-dom";
// import { InputText } from 'primereact/inputtext';
// import { Button } from 'primereact/button';

class Register extends Component {
    constructor(props) {
        super(props);
        this.state = {
            registerform: {
                name: "",
                emailId:"",
                contactNo:"",
                password: ""
            },
            registerformErrorMessage: {
                name: "",
                emailId:"",
                contactNo:"",
                password: ""
            },
            registerformValid: {
                name: false,
                emailId:false,
                contactNo:false,
                password: false,
                buttonActive: false
            },
            successMessage: "",
            errorMessage: "",
            userId: "",
            isRegisterSuccess : false
        }
    }

    
    handleChange = (event) => {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        const { registerform } = this.state;
        this.setState({
            registerform: { ...registerform, [name]: value }
        });
        this.validateField(name, value);
        // console.log(this.state.loginform[name], name);
    }
    

    register = () => {
        const { registerform } = this.state;
        axios.post(backendUrlUser+'/register', registerform)
            .then(response => {
                this.setState({ 
                    isRegisterSuccess : true
                });
            }).catch(error => {
                this.setState({errorMessage : error.response.data.message});
            })
        // console.log(this.state.loginform.contactNo, this.state.loginform.password);
    }

    handleSubmit = (event) => {
        event.preventDefault();
        this.register();
    }

    validateField = (fieldName, value) => {
        let fieldValidationErrors = this.state.registerformErrorMessage;
        let formValid = this.state.registerformValid;
        switch (fieldName) {
            case "name":
                let uNameRegex = /^[a-zA-Z]+[\s]?[a-zA-Z]$/
                if (!value || value === "") {
                    fieldValidationErrors.name = "Please enter your Name";
                    formValid.name = false;
                } else if (!value.match(uNameRegex)) {
                    fieldValidationErrors.name = "Enter valid username";
                    formValid.name = false;
                } else {
                    fieldValidationErrors.name = "";
                    formValid.name = true;
                }
                break;
            case "emailId":
                let emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z]+\.com$/
                if (!value || value === "") {
                    fieldValidationErrors.emailId = "Please enter your Email Id";
                    formValid.emailId = false;
                } else if (!value.match(emailRegex)) {
                    fieldValidationErrors.emailId = "Enter valid Email Id";
                    formValid.emailId = false;
                } else {
                    fieldValidationErrors.emailId = "";
                    formValid.emailId = true;
                }
                break;
            case "contactNo":
                let cnoRegex = /^[1-9]\d{9}$/
                if (!value || value === "") {
                    fieldValidationErrors.contactNo = "Please enter your contact Number";
                    formValid.contactNo = false;
                } else if (!value.match(cnoRegex)) {
                    fieldValidationErrors.contactNo = "Contact number should be a valid 10 digit number";
                    formValid.contactNo = false;
                } else {
                    fieldValidationErrors.contactNo = "";
                    formValid.contactNo = true;
                }
                break;
            case "password":
                if (!value || value === "") {
                    fieldValidationErrors.password = "Password is manadatory";
                    formValid.password = false;
                     } else if (!(value.match(/[a-zA-z]/) && value.match(/[0-9]/) && value.match(/[!@#$%^&*]/))) {
                            fieldValidationErrors.password = "Please Enter a valid password"
                            formValid.password = false;
                } else {
                    fieldValidationErrors.password = "";
                    formValid.password = true;
                }
                break;
            default:
                break;
        }
        formValid.buttonActive = formValid.name && formValid.emailId && formValid.contactNo && formValid.password;
        this.setState({
            registerformErrorMessage: fieldValidationErrors,
            registerformValid: formValid,
            successMessage: ""
        });
    }

    render() {
        /*if (this.state.loadHome === true) return <Redirect to={'/home/' + this.state.userId} />
        if (this.state.loadRegister === true) return <Redirect to={'/register'} />*/
        return (
            <div>
                <section id="registerPage" className="registerSection">    {/* *ngIf="!registerPage"  */}
                    <div className="container-fluid">
                        <div className="row">
        {!this.state.isRegisterSuccess ? (<div className="col-md-4 offset-4 ">
                                <h1>Join Us</h1>
                                <form className="form" onSubmit={this.handleSubmit}> {/* [formGroup]="loginForm" (ngSubmit)="login()" */}
                                    <div className="form-group">
                                        <label htmlFor="name">Name<span className="text-danger">*</span></label>
                                        <input
                                            type="text"
                                            value={this.state.registerform.name}
                                            onChange={this.handleChange}
                                            id="name"
                                            name="name"
                                            className="form-control"
                                        />
                                    </div>
                                    {this.state.registerformErrorMessage.name ? (<span className="text-danger">
                                        {this.state.registerformErrorMessage.name}
                                    </span>)
                                        : null}
                                    <div className="form-group">
                                        <label htmlFor="emailId">Email Id<span className="text-danger">*</span></label>
                                        <input
                                            type="email"
                                            value={this.state.registerform.emailId}
                                            onChange={this.handleChange}
                                            id="emailId"
                                            name="emailId"
                                            className="form-control"
                                        />
                                    </div>
                                    {this.state.registerformErrorMessage.emailId ? (<span className="text-danger">
                                        {this.state.registerformErrorMessage.emailId}
                                    </span>)
                                        : null}
                                    <div className="form-group">
                                        <label htmlFor="contactNo">Contact Number<span className="text-danger">*</span></label>
                                        <input
                                            type="number"
                                            value={this.state.registerform.contactNo}
                                            onChange={this.handleChange}
                                            id="contactNo"
                                            name="contactNo"
                                            className="form-control"
                                        />
                                    </div>
                                    {this.state.registerformErrorMessage.contactNo ? (<span className="text-danger">
                                        {this.state.registerformErrorMessage.contactNo}
                                    </span>)
                                        : null}

                                    <div className="form-group">
                                        <label htmlFor="uPass">Password<span className="text-danger">*</span></label>
                                        <input
                                            type="password"
                                            value={this.state.registerform.password}
                                            onChange={this.handleChange}
                                            id="uPass"
                                            name="password"
                                            className="form-control"
                                        />
                                    </div>
                                    {this.state.registerformErrorMessage.password ? (<span className="text-danger">
                                        {this.state.registerformErrorMessage.password}
                                    </span>)
                                        : null}<br />
                                    
                                    <div style = {{paddingBottom : 1}}>
                                        <span className="text-danger">*</span> 
                                        marked feilds are mandatory
                                    </div>
                                    <br />
                                    {/* <div class="form-group">
                                        <div class="text-danger">
                                            <h6>{{ errorMessage }}</h6>
                                        </div>
                                    </div> */}

                                    <button
                                        type="submit"
                                        disabled={!this.state.registerformValid.buttonActive}
                                        className="btn btn-primary"
                                    >
                                        Register
                                    </button>
                                    <div style = {{paddingTop : 10}}>
                                        <h5 className="text text-danger" style = {{ paddingTop : 2 }}>{this.state.errorMessage}</h5>     
                                    </div>
                                   
                                </form>
                                <br />
                                {/* <!--can be a button or a link based on need --> */}
                                {/* <button className="btn btn-primary" onClick={this.handleClick} >Click here to Register</button> */}
                            </div>
                            
                            ) : (
                                <div className="col-md-4 offset-4 " style={{ paddingBottom : 80 }}>
                                    
                                     <h2 className="text text-success">Successfully registered!</h2>
                                     <Link to='/login'><h2 className="text text-primary"><b>Click here to login</b></h2></Link>
                                    
                                </div>
                            ) }
                        </div>
                    </div>
                </section>
                {/* <div * ngIf= "!registerPage" >
            <router-outlet></router-outlet>
            </div > */}
                {/* *ngIf="!registerPage" */}
                {/* </div > */}
            </div>

        )
    }
}

export default Register;