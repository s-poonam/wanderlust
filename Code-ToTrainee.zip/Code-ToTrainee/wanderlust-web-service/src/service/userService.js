const userDB = require('../model/userModel');

const userService = {}

//login a user
userService.login = (contactNo, userPassword) => {
    return userDB.checkUser(contactNo).then((user) => {
        if (user == null) {
            let err = new Error("Enter registered contact number! If not registered, please register")
            err.status = 404
            throw err
        }
        else {
            return userDB.getPassword(contactNo).then((password) => {
                if (password != userPassword) {
                    let err = new Error("Incorrect password")
                    err.status = 406
                    throw err
                }
                else {
                    return user;
                }
            })
        }
    })
}

userService.generateUserId = () => {
    return userDB.generateUserId().then((userId) => {
        return userId; 
    });
}


userService.checkContactNumberExist = (contactNo) => {
    return userDB.checkContactNumberExist(contactNo).then((isExist)=>{
        return isExist;
    });
}


//register a user
userService.registerUser = async(obj) => {
    let isContactExist = await userService.checkContactNumberExist(obj.contactNo);
    if (isContactExist) {
        let err = new Error("Contact number is already registered...!!!");
        err.status = 404;
        throw err;
    }
    let userId = await userService.generateUserId();
    obj.userId = userId;
    return userDB.registerUser(obj).then((res) => {
        if (res == null) {
            let err = new Error("Registration is not successful")
            err.status = 404;
            throw err;
        }else {
           return res;
        }
    })
}

module.exports = userService
