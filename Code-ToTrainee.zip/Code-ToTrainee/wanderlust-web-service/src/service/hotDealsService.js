const hotDealsModel = require('../model/hotDealsModel');
const hotDealsService = {};

hotDealsService.getHotDeals = () => {
    return hotDealsModel.getHotDeals().then((res) => { 
        if (!res){
            let error = new Error("Enter registered contact number! If not registered, please register")
            error.status = 404;
            throw error;
        }
        return res;
    });
}

hotDealsService.checkAvailability = (destId,noOfPersons) => {
    return hotDealsModel.checkAvailability(destId).then((available) => {      
        if (available < noOfPersons) {
            let err = new Error("There are only "+available+" travellers allowed");
            err.status = 404
            throw err; 
        }
        return;
    });
}

hotDealsService.getHotDealDestination = (destId) => {
    return hotDealsModel.getHotDealDestination(destId).then((res) => { 
        return res;
    });
}

module.exports = hotDealsService
