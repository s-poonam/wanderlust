const destinationModel = require('../model/destinationModel');
const destinationService = {};

destinationService.getDestination = (continent) => {
    return destinationModel.getDestination(continent).then((res) => { 
        if (!res){
            let error = new Error("data not found");
            error.status = 404;
            throw error;
        }
        return res;
    });
}


destinationService.checkAvailability = (destId,noOfPersons) => {
    return destinationModel.checkAvailability(destId).then((available) => { 
        if (available < noOfPersons) {
            let err = new Error("There are only "+available+" travellers allowed");
            err.status = 404
            throw err; 
        }
        return;
    });
}

destinationService.getDestinationId = (destId) => {
    return destinationModel.getDestinationId(destId).then((res) => { 
        if (!res){
            let error = new Error("data not found");
            error.status = 404;
            throw error;
        }
        return res;
    });
}
module.exports = destinationService
