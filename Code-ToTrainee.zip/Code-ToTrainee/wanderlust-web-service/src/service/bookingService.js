const bookingModel = require('../model/bookingModel');
const destinationModel = require('../model/destinationModel');
const hotDealsModel = require('../model/hotDealsModel');
const destinationService = require('../service/destinationService');
const hotDealsService = require('../service/hotDealsService');
const bookingService = {}


bookingService.createBooking = async(obj) => {
    let destId = obj.destId;
    if (destId[0] === 'D') {
        await destinationService.checkAvailability(obj.destId,obj.noOfPersons);
    } else {
        await hotDealsService.checkAvailability(obj.destId,obj.noOfPersons);
    }    
    return bookingModel.createBooking(obj).then((response) => {
        if (response == null) {
            let err = new Error("Unable to create booking");
            err.status = 404
            throw err
        }else {
            return response;
        }
    });
}

bookingService.getBooking=(userId)=>{
    return bookingModel.getBooking(userId).then((response)=>{
        if(response.length > 0){
            return response;
        }else{
            return [];
        }
    });
}

bookingService.cancelBooking = async(bookingId) => {
    let response = await bookingModel.getBookingDetails(bookingId);
    if (response) {
        let destId = response['destId'];
        if (destId[0] === 'D') {
            await destinationModel.updateAvailability(destId,response.noOfPersons);
        } else {
            await hotDealsModel.updateAvailability(destId,response.noOfPersons);
        }
    }
    return bookingModel.cancelBooking(bookingId).then((response)=>{
        return response;
    });
}

module.exports = bookingService
