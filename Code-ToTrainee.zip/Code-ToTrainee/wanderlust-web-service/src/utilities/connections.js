const { Schema } = require("mongoose");
const Mongoose = require("mongoose")
Mongoose.Promise = global.Promise;
const url = "mongodb://localhost:27017/Wanderlust_DB";

let bookingSchema = Schema({
    bookingId: String,
    destId: String,
    userId: String,
    destinationName: String,
    checkInDate: String,
    checkOutDate: String,
    noOfPersons: Number,
    totalCharges: Number,
    isCancel: Number,
    timeStamp : Date
},  { timestamps : true },{ collection: "Bookings" });


let userSchema = Schema({
    name: String,
    userId: String,
    emailId: String,
    contactNo: Number,
    password: String,
    bookings: [String]
},  { timestamps : true },{ collection: "User" });


let hotDealsSchema = Schema({
    destinationId: String,
    continent: String,
    name: String,
    imageUrl: String,
    details: {},
    noOfNights: Number,
    flightCharges: Number,
    chargesPerPerson: Number,
    discount: Number,
    availability: Number 
},  { timestamps : true },{ collection: "Hotdeals" })

let destinationSchema = Schema({
    destinationId: String,
    continent: String,
    name: String,
    imageUrl: String,
    details: {},
    noOfNights: Number,
    flightCharges: Number,
    chargesPerPerson: Number,
    discount: Number,
    availability: Number 
},  { timestamps : true },{ collection: "Destinations" })


let collection = {};

collection.getUserCollection = () => {
    return Mongoose.connect(url, { useNewUrlParser: true }).then((database) => {
        return database.model('User', userSchema,'User')
    }).catch((error) => {
        let err = new Error("Could not connect to Database");
        err.status = 500;
        throw err;
    })
}

collection.getBookingCollection=()=>{
    return Mongoose.connect(url,{useNewUrlParser: true}).then((database)=>{
        return database.model('Bookings',bookingSchema,'Bookings')
    }).catch((error)=>{
        let err = new Error("Could not connect to Database");
        err.status = 500;
        throw err;
    })
}

collection.getHotDealCollection = () => {
    return Mongoose.connect(url, { useNewUrlParser: true }).then((database) => {
        return database.model('Hotdeals', hotDealsSchema,'Hotdeals')
    }).catch((error) => {
        let err = new Error("Could not connect to Database");
        err.status = 500;
        throw err;
    })
}

collection.getDestinationCollection = () => {
    return Mongoose.connect(url, { useNewUrlParser: true }).then((database) => {
        return database.model('Destinations', destinationSchema,'Destinations')
    }).catch((error) => {
        let err = new Error("Could not connect to Database");
        err.status = 500;
        throw err;
    })
}

module.exports = collection;
