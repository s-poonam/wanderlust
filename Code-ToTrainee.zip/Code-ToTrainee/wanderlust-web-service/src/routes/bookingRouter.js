const express = require('express');
const router = express.Router();
const bookingService = require('../service/bookingService')
const bookingClass = require('../model/bookingClasses/booking');


router.post('/create', function (req, res, next) {
    let obj = new bookingClass(req.body);
    bookingService.createBooking(obj).then(function (response) {
        res.json({'bookings' : response});
    }).catch(err => next(err));
});

router.get('/getBooking/:userId', function (req, res, next) {
    let userId = req.params.userId;
    bookingService.getBooking(userId).then(function (response) {
        res.json({'bookings' : response});
    }).catch(err => next(err));
});



router.delete('/cancelBooking/:bookingId', function (req, res, next) {
    let bookingId = req.params.bookingId;
    console.log(bookingId);
    
    bookingService.cancelBooking(bookingId).then(function (response) {
        res.json({'bookings' : response,'msg' : 'deleted successfully...!!!'});
    }).catch(err => next(err));
});

module.exports = router;

