const express = require('express');
const router = express.Router();
const hotDealsService = require('../service/hotDealsService');
const destinationService = require('../service/destinationService');

router.get("/hotDeals", (req, res, next) => {
    hotDealsService.getHotDeals().then((hotDeals) => {
        res.json({'hotDeals' : hotDeals});
    }).catch(err => next(err));
});

router.get("/destinations/:continent", (req, res, next) => {
    let continent = req.params.continent;
    destinationService.getDestination(continent).then((packages) => {
        res.json({'packages' : packages});
    }).catch(err => next(err));
});

router.get("/getDestination/:destinationId", (req, res, next) => {
    let destinationId = req.params.destinationId;
    destinationService.getDestinationId(destinationId).then((packages) => {
        res.json({'packages' : packages});
    }).catch(err => next(err));
});

router.get("/hotDeals/:destinationId", (req, res, next) => {
    let destinationId = req.params.destinationId;
    hotDealsService.getHotDealDestination(destinationId).then((packages) => {
        res.json({'packages' : packages});
    }).catch(err => next(err));
});

module.exports = router;

