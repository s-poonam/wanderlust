const userDetails = require('./beanClasses/users');
const connection = require("../utilities/connections");

const usersDB = {}

usersDB.checkUser = (contactNo) => {
    return connection.getUserCollection().then((collection) => {
        return collection.findOne({ "contactNo": contactNo }).then((customerContact) => {
            if (customerContact) {
                return new userDetails(customerContact);
            }
            else return null;
        })
    })
}

usersDB.getPassword = (contactNo) => {
    return connection.getUserCollection().then((collection) => {
        return collection.find({ "contactNo": contactNo }, { _id: 0, password: 1 }).then((password) => {
            if (password.length != 0)
                return password[0].password;
            else
                return null;
        })
    })
}

//generate the userId based on previous userId
usersDB.generateUserId = () => {
    return connection.getUserCollection().then(async(collection) => {
        let response = await collection.findOne().sort({createdAt: 'desc'}).lean().exec();
        if (!response) {
            return 'U1001';
        } else {
            let userId = response.userId.slice(1);
            userId = Number(userId) + 1;
            userId = 'U' + String(userId);
            return userId;
        }
    });    
}
//end

usersDB.checkContactNumberExist = async(contactNo) => {
    return connection.getUserCollection().then(async(collection) => {
        let response = await collection.findOne({contactNo:contactNo}).lean().exec();
        if(response) {
            return true;
        }
        return false;
    });
}

usersDB.registerUser = (obj) => {
    return connection.getUserCollection().then((collection) => {
        return collection.create( obj ).then((res) => {
            if (res) {
                return res;
            }
            else return null;
        })
    })
}

module.exports = usersDB;
