const connection = require("../utilities/connections");
const hotDeals = {};

hotDeals.getHotDeals = () => {
    return connection.getHotDealCollection().then(async(hotDealModel) => {
        let response = await hotDealModel.find().lean().exec();
        if (!response) {
            return null;
        }
        return response;
    });
}

hotDeals.updateAvailability = (destId,availability) => {
    return connection.getHotDealCollection().then((hotDealCollection) => {
        return hotDealCollection.updateOne({destinationId:destId},{$inc:{availability: availability}}).then((response)=>{
            return response;
        });
    });
}

hotDeals.checkAvailability = (destId) => {
    return connection.getHotDealCollection().then((hotDealCollection) => {
        return hotDealCollection.findOne({destinationId:destId}).then((response)=>{
            if (response) {
                return response['availability'];
            }
            return null;
        });
    });
}


hotDeals.getHotDealDestination = (destId) => {
    return connection.getHotDealCollection().then(async(hotDealModel) => {
        let response = await hotDealModel.find({destinationId: destId}).lean().exec();
        if (!response) {
            return [];
        }
        return response;
    });
}

module.exports  = hotDeals;