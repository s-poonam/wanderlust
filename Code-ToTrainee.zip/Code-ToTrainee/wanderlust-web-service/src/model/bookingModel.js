const bookingDetails = require('./bookingClasses/booking');
const connection = require("../utilities/connections");
const destinationModel = require("../model/destinationModel");
const hotDealsModel = require("../model/hotDealsModel");

const bookingDB = {}

bookingDB.checkAvailability = (destId) => {
    return connection.getDestinationCollection().then((destCollection) => {
        return destCollection.findOne({destinationId:destId}).then((response)=>{
            if (response) {
                return response['availability'];
            }
            return null;
        });
    });
}

bookingDB.createBooking = async(obj) => {
    let bookingId = await bookingDB.generateBookingId();
    obj.bookingId = bookingId;
    obj.isCancel = 0;
    return connection.getBookingCollection().then((collection) => {
        return collection.create( obj ).then(async(res) => {
            if (res) {
                let destId = obj.destId;
                let noOfPersons = Number(obj.noOfPersons);
                if (destId[0] === 'D') {
                    await destinationModel.updateAvailability(destId,-noOfPersons);
                } else {
                    await hotDealsModel.updateAvailability(destId,-noOfPersons);
                }
                return res;
            }
            else return null;
        })
    })
}

bookingDB.generateBookingId = () => {
    return connection.getBookingCollection().then(async(collection) => {
        let response = await collection.findOne().sort({bookingId: 'desc'}).lean().exec();
        if (!response) {
            return 'B1001';
        } else {
            let bookingId = response.bookingId.slice(1);
            bookingId = Number(bookingId) + 1;
            bookingId = 'B' + String(bookingId);
            return bookingId;
        }
    });    
}

bookingDB.getBooking=(userId)=>{
    return connection.getBookingCollection().then((collection)=>{
        return collection.find({userId:userId,isCancel:0}).then((res)=>{
            return res;
        });
    });
}

bookingDB.cancelBooking=(bookingId)=>{
    return connection.getBookingCollection().then((collection)=>{
        return collection.updateOne({bookingId:bookingId},{isCancel:1}).then((res)=>{
            return res;
        }).catch((err)=>{
            console.log(err);
            
        });
    });
}

bookingDB.getBookingDetails = (bookingId) => {
    return connection.getBookingCollection().then((collection)=>{
        return collection.findOne({bookingId:bookingId}).then((res)=>{
            return res;
        });
    });
}

module.exports = bookingDB;
