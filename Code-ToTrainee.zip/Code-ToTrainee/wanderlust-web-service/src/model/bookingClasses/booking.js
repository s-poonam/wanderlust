class Booking {
    constructor(obj) {
        this.bookingId= obj.bookingId;
        this.destId= obj.destId;
        this.userId= obj.userId;
        this.destinationName= obj.destinationName;
        this.checkInDate= obj.checkInDate;
        this.checkOutDate= obj.checkOutDate;
        this.noOfPersons= obj.noOfPersons;
        this.totalCharges= obj.totalCharges;
    }
}

module.exports = Booking;