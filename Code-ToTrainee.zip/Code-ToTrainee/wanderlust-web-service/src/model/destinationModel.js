const connection = require("../utilities/connections");
const destination = {};

destination.getDestination = (continent) => {
    return connection.getDestinationCollection().then(async(destinationModel) => {
        let response = await destinationModel.find({continent: continent[0].toUpperCase() + continent.slice(1) }).lean().exec();
        if (!response) {
            return null;
        }
        return response;
    });
}

destination.checkAvailability = (destId) => {
    return connection.getDestinationCollection().then((destinationModel) => {
        return destinationModel.findOne({destinationId:destId}).then((response)=>{
            if (response) {
                return response['availability'];
            }
            return null;
        });
    });
}

destination.updateAvailability = (destId,availability) => {
    return connection.getDestinationCollection().then((destCollection) => {
        return destCollection.updateOne({destinationId:destId},{$inc:{availability: availability}}).then((response)=>{
            return response;
        });
    });    
}

destination.getDestinationId = (destId) => {
    console.log(destId);
    
    return connection.getDestinationCollection().then(async(destinationModel) => {
        let response = await destinationModel.find({destinationId: destId }).lean().exec();
        if (!response) {
            return null;
        }
        return response;
    });
}
module.exports  = destination;